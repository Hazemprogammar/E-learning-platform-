import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  BookOpen, 
  FileText, 
  BarChart3, 
  Bell, 
  Calendar, 
  User,
  Home
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';

const StudentLayout = ({ children, activeTab = 'dashboard' }) => {
  const { t } = useTranslation();

  const sidebarItems = [
    { id: 'dashboard', label: t('dashboard'), icon: Home },
    { id: 'subjects', label: t('subjects'), icon: BookOpen },
    { id: 'assignments', label: t('assignments'), icon: FileText },
    { id: 'grades', label: t('grades'), icon: BarChart3 },
    { id: 'announcements', label: t('announcements'), icon: Bell },
    { id: 'attendance', label: t('attendance'), icon: Calendar },
    { id: 'profile', label: t('profile'), icon: User },
  ];

  const handleLogout = () => {
    // Placeholder for logout logic
    console.log('Logout clicked');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header userRole="student" onLogout={handleLogout} />
      
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white dark:bg-gray-800 shadow-sm min-h-[calc(100vh-4rem)] border-r border-gray-200 dark:border-gray-700">
          <nav className="p-4">
            <div className="space-y-2">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    className={`w-full justify-start ${
                      isActive 
                        ? 'bg-primary text-primary-foreground' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <Icon className="mr-3 h-4 w-4" />
                    {item.label}
                  </Button>
                );
              })}
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default StudentLayout;

