import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      // Navigation
      home: "Home",
      about: "About Us",
      contact: "Contact",
      faq: "FAQ",
      login: "Login",
      register: "Register",
      logout: "Logout",
      
      // Roles
      student: "Student",
      teacher: "Teacher",
      admin: "Admin",
      selectRole: "Select Your Role",
      
      // Common
      dashboard: "Dashboard",
      profile: "Profile",
      settings: "Settings",
      save: "Save",
      cancel: "Cancel",
      edit: "Edit",
      delete: "Delete",
      add: "Add",
      search: "Search",
      filter: "Filter",
      submit: "Submit",
      loading: "Loading...",
      
      // Student Panel
      subjects: "Subjects",
      assignments: "Assignments",
      grades: "Grades",
      announcements: "Announcements",
      attendance: "Attendance",
      schedule: "Schedule",
      upcomingClasses: "Upcoming Classes",
      dueDates: "Due Dates",
      performance: "Performance",
      
      // Teacher Panel
      classManagement: "Class Management",
      uploadMaterials: "Upload Materials",
      gradeSubmission: "Grade Submission",
      markAttendance: "Mark Attendance",
      
      // Admin Panel
      studentManagement: "Student Management",
      teacherManagement: "Teacher Management",
      subjectManagement: "Subject Management",
      scheduleBuilder: "Schedule Builder",
      statistics: "Statistics",
      
      // Forms
      email: "Email",
      password: "Password",
      confirmPassword: "Confirm Password",
      firstName: "First Name",
      lastName: "Last Name",
      phoneNumber: "Phone Number",
      dateOfBirth: "Date of Birth",
      
      // Placeholders
      studentName: "{{StudentName}}",
      teacherName: "{{TeacherName}}",
      subjectTitle: "{{SubjectTitle}}",
      grade: "{{Grade}}",
      date: "{{Date}}",
      lessonTitle: "{{LessonTitle}}",
      pdfUrl: "{{PDF_URL}}",
      
      // Theme
      darkMode: "Dark Mode",
      lightMode: "Light Mode",
      language: "Language",
    }
  },
  ar: {
    translation: {
      // Navigation
      home: "الرئيسية",
      about: "من نحن",
      contact: "اتصل بنا",
      faq: "الأسئلة الشائعة",
      login: "تسجيل الدخول",
      register: "التسجيل",
      logout: "تسجيل الخروج",
      
      // Roles
      student: "طالب",
      teacher: "معلم",
      admin: "إدارة",
      selectRole: "اختر دورك",
      
      // Common
      dashboard: "لوحة التحكم",
      profile: "الملف الشخصي",
      settings: "الإعدادات",
      save: "حفظ",
      cancel: "إلغاء",
      edit: "تعديل",
      delete: "حذف",
      add: "إضافة",
      search: "بحث",
      filter: "تصفية",
      submit: "إرسال",
      loading: "جاري التحميل...",
      
      // Student Panel
      subjects: "المواد",
      assignments: "الواجبات",
      grades: "الدرجات",
      announcements: "الإعلانات",
      attendance: "الحضور",
      schedule: "الجدول",
      upcomingClasses: "الحصص القادمة",
      dueDates: "مواعيد التسليم",
      performance: "الأداء",
      
      // Teacher Panel
      classManagement: "إدارة الفصول",
      uploadMaterials: "رفع المواد",
      gradeSubmission: "إدخال الدرجات",
      markAttendance: "تسجيل الحضور",
      
      // Admin Panel
      studentManagement: "إدارة الطلاب",
      teacherManagement: "إدارة المعلمين",
      subjectManagement: "إدارة المواد",
      scheduleBuilder: "بناء الجدول",
      statistics: "الإحصائيات",
      
      // Forms
      email: "البريد الإلكتروني",
      password: "كلمة المرور",
      confirmPassword: "تأكيد كلمة المرور",
      firstName: "الاسم الأول",
      lastName: "اسم العائلة",
      phoneNumber: "رقم الهاتف",
      dateOfBirth: "تاريخ الميلاد",
      
      // Placeholders
      studentName: "{{StudentName}}",
      teacherName: "{{TeacherName}}",
      subjectTitle: "{{SubjectTitle}}",
      grade: "{{Grade}}",
      date: "{{Date}}",
      lessonTitle: "{{LessonTitle}}",
      pdfUrl: "{{PDF_URL}}",
      
      // Theme
      darkMode: "الوضع المظلم",
      lightMode: "الوضع المضيء",
      language: "اللغة",
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: false,
    
    interpolation: {
      escapeValue: false,
    },
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
    }
  });

export default i18n;

