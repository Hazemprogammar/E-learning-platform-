const API_BASE_URL = 'http://localhost:8000/api';

class ApiService {
  constructor() {
    this.token = localStorage.getItem('auth_token');
  }

  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('auth_token', token);
    } else {
      localStorage.removeItem('auth_token');
    }
  }

  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    return headers;
  }

  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const config = {
      headers: this.getHeaders(),
      ...options,
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'API request failed');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Auth methods
  async login(email, password) {
    const response = await this.request('/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (response.success) {
      this.setToken(response.data.token);
    }

    return response;
  }

  async register(userData) {
    const response = await this.request('/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });

    if (response.success) {
      this.setToken(response.data.token);
    }

    return response;
  }

  async logout() {
    try {
      await this.request('/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  async getProfile() {
    return this.request('/me');
  }

  async updateProfile(userData) {
    return this.request('/profile', {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  }

  // Student methods
  async getStudentDashboard() {
    return this.request('/student/dashboard');
  }

  async getStudentSubjects() {
    return this.request('/student/subjects');
  }

  async getStudentClasses() {
    return this.request('/student/classes');
  }

  async getStudentAssignments() {
    return this.request('/student/assignments');
  }

  async getStudentGrades() {
    return this.request('/student/grades');
  }

  async getStudentAttendance() {
    return this.request('/student/attendance');
  }

  async getStudentAnnouncements() {
    return this.request('/student/announcements');
  }

  async getStudentMaterials() {
    return this.request('/student/materials');
  }

  // Teacher methods
  async getTeacherDashboard() {
    return this.request('/teacher/dashboard');
  }

  async getTeacherClasses() {
    return this.request('/teacher/classes');
  }

  async getTeacherAssignments() {
    return this.request('/teacher/assignments');
  }

  async createAssignment(assignmentData) {
    return this.request('/teacher/assignments', {
      method: 'POST',
      body: JSON.stringify(assignmentData),
    });
  }

  async getTeacherGrades() {
    return this.request('/teacher/grades');
  }

  async submitGrade(gradeData) {
    return this.request('/teacher/grades', {
      method: 'POST',
      body: JSON.stringify(gradeData),
    });
  }

  async getTeacherAttendance() {
    return this.request('/teacher/attendance');
  }

  async markAttendance(attendanceData) {
    return this.request('/teacher/attendance', {
      method: 'POST',
      body: JSON.stringify(attendanceData),
    });
  }

  async getTeacherAnnouncements() {
    return this.request('/teacher/announcements');
  }

  async createAnnouncement(announcementData) {
    return this.request('/teacher/announcements', {
      method: 'POST',
      body: JSON.stringify(announcementData),
    });
  }

  // Admin methods
  async getAdminDashboard() {
    return this.request('/admin/dashboard');
  }

  async getAdminStatistics() {
    return this.request('/admin/statistics');
  }

  async getUsers() {
    return this.request('/admin/users');
  }

  async createUser(userData) {
    return this.request('/admin/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async getStudents() {
    return this.request('/admin/students');
  }

  async getTeachers() {
    return this.request('/admin/teachers');
  }

  async getSubjects() {
    return this.request('/admin/subjects');
  }

  async createSubject(subjectData) {
    return this.request('/admin/subjects', {
      method: 'POST',
      body: JSON.stringify(subjectData),
    });
  }

  async getClasses() {
    return this.request('/admin/classes');
  }

  async createClass(classData) {
    return this.request('/admin/classes', {
      method: 'POST',
      body: JSON.stringify(classData),
    });
  }
}

export default new ApiService();

