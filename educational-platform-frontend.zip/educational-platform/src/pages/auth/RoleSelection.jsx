import React from 'react';
import { useTranslation } from 'react-i18next';
import { Users, UserCheck, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/Header';

const RoleSelection = () => {
  const { t } = useTranslation();

  const roles = [
    {
      id: 'student',
      title: t('student'),
      description: 'Access your courses, assignments, and grades',
      icon: Users,
      color: 'bg-blue-500 hover:bg-blue-600',
    },
    {
      id: 'teacher',
      title: t('teacher'),
      description: 'Manage classes, upload materials, and grade students',
      icon: UserCheck,
      color: 'bg-green-500 hover:bg-green-600',
    },
    {
      id: 'admin',
      title: t('admin'),
      description: 'Manage the entire school system and users',
      icon: Settings,
      color: 'bg-purple-500 hover:bg-purple-600',
    },
  ];

  const handleRoleSelect = (roleId) => {
    // Placeholder for role selection logic
    console.log('Selected role:', roleId);
    alert(`Role selection functionality will be implemented. Selected: ${roleId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {t('selectRole')}
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Choose your role to access the appropriate dashboard
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {roles.map((role) => {
              const Icon = role.icon;
              
              return (
                <Card 
                  key={role.id} 
                  className="hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => handleRoleSelect(role.id)}
                >
                  <CardHeader className="text-center">
                    <div className={`w-16 h-16 rounded-full ${role.color} flex items-center justify-center mx-auto mb-4`}>
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-xl font-bold">
                      {role.title}
                    </CardTitle>
                    <CardDescription className="text-center">
                      {role.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <Button 
                      className="w-full"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRoleSelect(role.id);
                      }}
                    >
                      Continue as {role.title}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Need help? Contact your system administrator
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoleSelection;

