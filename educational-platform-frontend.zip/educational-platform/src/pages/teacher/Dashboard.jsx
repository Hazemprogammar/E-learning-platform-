import React from 'react';
import { useTranslation } from 'react-i18next';
import { Users, BookOpen, FileText, Calendar, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import TeacherLayout from '@/layouts/TeacherLayout';

const TeacherDashboard = () => {
  const { t } = useTranslation();

  const todayClasses = [
    { subject: '{{SubjectName1}}', time: '{{ClassTime1}}', room: '{{ClassRoom1}}', students: '{{StudentCount1}}' },
    { subject: '{{SubjectName2}}', time: '{{ClassTime2}}', room: '{{ClassRoom2}}', students: '{{StudentCount2}}' },
    { subject: '{{SubjectName3}}', time: '{{ClassTime3}}', room: '{{ClassRoom3}}', students: '{{StudentCount3}}' },
  ];

  const pendingTasks = [
    { task: 'Grade {{AssignmentName1}}', subject: '{{SubjectName1}}', count: '{{PendingCount1}}' },
    { task: 'Review {{AssignmentName2}}', subject: '{{SubjectName2}}', count: '{{PendingCount2}}' },
    { task: 'Upload materials for {{LessonName}}', subject: '{{SubjectName3}}', count: '1' },
  ];

  return (
    <TeacherLayout activeTab="dashboard">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {t('dashboard')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Welcome back, {{TeacherName}}!
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{TotalStudents}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Subjects Teaching</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{SubjectsTeaching}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Grades</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{PendingGrades}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Classes Today</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{ClassesToday}}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Today's Classes */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Today's Classes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {todayClasses.map((class_, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">{class_.subject}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Room: {class_.room}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{class_.students} students</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-blue-600">{class_.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Pending Tasks */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Pending Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingTasks.map((task, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">{task.task}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{task.subject}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-orange-600">{task.count}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </TeacherLayout>
  );
};

export default TeacherDashboard;

