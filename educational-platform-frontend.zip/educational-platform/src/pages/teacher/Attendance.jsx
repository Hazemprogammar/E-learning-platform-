import React from 'react';
import { useTranslation } from 'react-i18next';
import { Calendar, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import TeacherLayout from '@/layouts/TeacherLayout';

const TeacherAttendance = () => {
  const { t } = useTranslation();

  const students = [
    { name: '{{StudentName1}}', id: '{{StudentID1}}', status: 'present' },
    { name: '{{StudentName2}}', id: '{{StudentID2}}', status: 'absent' },
    { name: '{{StudentName3}}', id: '{{StudentID3}}', status: 'present' },
  ];

  return (
    <TeacherLayout activeTab="attendance">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('markAttendance')}</h1>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Mark Attendance - {{Date}} - {{SubjectName}}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {students.map((student, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">{student.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">ID: {student.id}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant={student.status === 'present' ? 'default' : 'outline'}
                      className="flex items-center gap-1"
                    >
                      <CheckCircle className="h-4 w-4" />
                      Present
                    </Button>
                    <Button 
                      size="sm" 
                      variant={student.status === 'absent' ? 'destructive' : 'outline'}
                      className="flex items-center gap-1"
                    >
                      <XCircle className="h-4 w-4" />
                      Absent
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6">
              <Button className="w-full">Save Attendance</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </TeacherLayout>
  );
};

export default TeacherAttendance;

