import React from 'react';
import { useTranslation } from 'react-i18next';
import { Bell, Plus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import TeacherLayout from '@/layouts/TeacherLayout';

const TeacherAnnouncements = () => {
  const { t } = useTranslation();

  return (
    <TeacherLayout activeTab="announcements">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('announcements')}</h1>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Create Announcement
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Recent Announcements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-400">
              Announcement management functionality will be implemented here.
            </p>
          </CardContent>
        </Card>
      </div>
    </TeacherLayout>
  );
};

export default TeacherAnnouncements;

