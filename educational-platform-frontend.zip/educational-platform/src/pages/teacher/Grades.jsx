import React from 'react';
import { useTranslation } from 'react-i18next';
import { BarChart3, Edit } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import TeacherLayout from '@/layouts/TeacherLayout';

const TeacherGrades = () => {
  const { t } = useTranslation();

  const students = [
    { name: '{{StudentName1}}', id: '{{StudentID1}}', assignment1: '{{Grade1}}', assignment2: '{{Grade2}}', average: '{{Average1}}' },
    { name: '{{StudentName2}}', id: '{{StudentID2}}', assignment1: '{{Grade3}}', assignment2: '{{Grade4}}', average: '{{Average2}}' },
    { name: '{{StudentName3}}', id: '{{StudentID3}}', assignment1: '{{Grade5}}', assignment2: '{{Grade6}}', average: '{{Average3}}' },
  ];

  return (
    <TeacherLayout activeTab="grades">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('gradeSubmission')}</h1>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Student Grades
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Student Name</th>
                    <th className="text-left p-2">ID</th>
                    <th className="text-left p-2">Assignment 1</th>
                    <th className="text-left p-2">Assignment 2</th>
                    <th className="text-left p-2">Average</th>
                    <th className="text-left p-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student, index) => (
                    <tr key={index} className="border-b">
                      <td className="p-2 font-medium">{student.name}</td>
                      <td className="p-2">{student.id}</td>
                      <td className="p-2">{student.assignment1}</td>
                      <td className="p-2">{student.assignment2}</td>
                      <td className="p-2 font-bold text-blue-600">{student.average}</td>
                      <td className="p-2">
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </TeacherLayout>
  );
};

export default TeacherGrades;

