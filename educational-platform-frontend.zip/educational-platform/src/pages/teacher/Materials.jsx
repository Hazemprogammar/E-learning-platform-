import React from 'react';
import { useTranslation } from 'react-i18next';
import { Upload, FileText, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import TeacherLayout from '@/layouts/TeacherLayout';

const TeacherMaterials = () => {
  const { t } = useTranslation();

  const materials = [
    { name: '{{MaterialName1}}', type: 'PDF', size: '{{FileSize1}}', uploadDate: '{{Date1}}' },
    { name: '{{MaterialName2}}', type: 'Video', size: '{{FileSize2}}', uploadDate: '{{Date2}}' },
    { name: '{{MaterialName3}}', type: 'Document', size: '{{FileSize3}}', uploadDate: '{{Date3}}' },
  ];

  return (
    <TeacherLayout activeTab="materials">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('uploadMaterials')}</h1>
          <Button className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Upload New Material
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Uploaded Materials</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {materials.map((material, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center gap-4">
                    <FileText className="h-8 w-8 text-blue-600" />
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">{material.name}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {material.type} • {material.size} • {material.uploadDate}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">Edit</Button>
                    <Button size="sm" variant="destructive">Delete</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </TeacherLayout>
  );
};

export default TeacherMaterials;

