import React from 'react';
import { useTranslation } from 'react-i18next';
import { Users, Calendar, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import TeacherLayout from '@/layouts/TeacherLayout';

const TeacherClasses = () => {
  const { t } = useTranslation();

  const classes = [
    { name: '{{ClassName1}}', subject: '{{SubjectName1}}', students: '{{StudentCount1}}', schedule: '{{Schedule1}}' },
    { name: '{{ClassName2}}', subject: '{{SubjectName2}}', students: '{{StudentCount2}}', schedule: '{{Schedule2}}' },
    { name: '{{ClassName3}}', subject: '{{SubjectName3}}', students: '{{StudentCount3}}', schedule: '{{Schedule3}}' },
  ];

  return (
    <TeacherLayout activeTab="classes">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('classManagement')}</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes.map((class_, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle>{class_.name}</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">{class_.subject}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4 mr-2" />
                  <span>{class_.students} students</span>
                </div>
                <div className="flex items-center text-gray-600 dark:text-gray-400">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>{class_.schedule}</span>
                </div>
                <div className="space-y-2">
                  <Button className="w-full">View Students</Button>
                  <Button className="w-full" variant="outline">Mark Attendance</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </TeacherLayout>
  );
};

export default TeacherClasses;

