import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronDown, ChevronUp } from 'lucide-react';
import Header from '@/components/Header';

const FAQ = () => {
  const { t } = useTranslation();
  const [openItems, setOpenItems] = useState({});

  const toggleItem = (index) => {
    setOpenItems(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const faqs = [
    {
      question: "How do I register for the platform?",
      answer: "You can register by clicking the 'Register' button and filling out the required information. Choose your role (Student or Teacher) during registration."
    },
    {
      question: "How do I reset my password?",
      answer: "Click on 'Forgot Password' on the login page and follow the instructions sent to your email."
    },
    {
      question: "Can I change my role after registration?",
      answer: "Role changes require administrator approval. Please contact the admin team for assistance."
    },
    {
      question: "How do I access my assignments?",
      answer: "Students can access assignments through the 'Assignments' section in their dashboard."
    },
    {
      question: "How do teachers upload materials?",
      answer: "Teachers can upload materials through the 'Upload Materials' section in their dashboard."
    },
    {
      question: "Is the platform mobile-friendly?",
      answer: "Yes, our platform is fully responsive and works on all devices including smartphones and tablets."
    },
    {
      question: "How do I contact technical support?",
      answer: "You can contact technical support through the Contact page or email {{SupportEmail}}."
    },
    {
      question: "Can I use the platform offline?",
      answer: "Some features require internet connection, but downloaded materials can be accessed offline."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              {t('faq')}
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Find answers to commonly asked questions about our platform.
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
                <button
                  className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg"
                  onClick={() => toggleItem(index)}
                >
                  <span className="text-lg font-semibold text-gray-900 dark:text-white">
                    {faq.question}
                  </span>
                  {openItems[index] ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>
                
                {openItems[index] && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-600 dark:text-gray-400">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Still have questions?
            </p>
            <a
              href="/contact"
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;

