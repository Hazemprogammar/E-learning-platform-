import React from 'react';
import { useTranslation } from 'react-i18next';
import Header from '@/components/Header';

const About = () => {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              {t('about')}
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              We are committed to providing the best digital education experience for students, teachers, and administrators.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-6">
                To revolutionize education through innovative technology solutions that make learning accessible, engaging, and effective for everyone.
              </p>
              <p className="text-lg text-gray-600 dark:text-gray-400">
                We believe that education is the foundation of progress, and our platform is designed to support educators and learners in achieving their full potential.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Our Values
              </h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-3">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Innovation in educational technology</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-3">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Accessibility for all learners</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-3">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Quality educational content</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-3">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Continuous improvement and support</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-20">
            <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
              Our Team
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-32 h-32 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{{TeamMember1}}</h3>
                <p className="text-gray-600 dark:text-gray-400">{{Position1}}</p>
              </div>
              <div className="text-center">
                <div className="w-32 h-32 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{{TeamMember2}}</h3>
                <p className="text-gray-600 dark:text-gray-400">{{Position2}}</p>
              </div>
              <div className="text-center">
                <div className="w-32 h-32 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{{TeamMember3}}</h3>
                <p className="text-gray-600 dark:text-gray-400">{{Position3}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;

