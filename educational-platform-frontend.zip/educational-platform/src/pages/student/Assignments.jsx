import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FileText, Calendar, Clock, CheckCircle, AlertCircle, Upload } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import StudentLayout from '@/layouts/StudentLayout';

const StudentAssignments = () => {
  const { t } = useTranslation();
  const [filter, setFilter] = useState('all');

  const assignments = [
    {
      id: 1,
      title: '{{AssignmentTitle1}}',
      subject: '{{SubjectName1}}',
      dueDate: '{{DueDate1}}',
      status: 'pending',
      description: '{{AssignmentDescription1}}',
      points: '{{Points1}}'
    },
    {
      id: 2,
      title: '{{AssignmentTitle2}}',
      subject: '{{SubjectName2}}',
      dueDate: '{{DueDate2}}',
      status: 'submitted',
      description: '{{AssignmentDescription2}}',
      points: '{{Points2}}'
    },
    {
      id: 3,
      title: '{{AssignmentTitle3}}',
      subject: '{{SubjectName3}}',
      dueDate: '{{DueDate3}}',
      status: 'graded',
      description: '{{AssignmentDescription3}}',
      points: '{{Points3}}',
      grade: '{{Grade3}}'
    },
    {
      id: 4,
      title: '{{AssignmentTitle4}}',
      subject: '{{SubjectName4}}',
      dueDate: '{{DueDate4}}',
      status: 'overdue',
      description: '{{AssignmentDescription4}}',
      points: '{{Points4}}'
    }
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'submitted':
        return <Badge variant="default"><Upload className="h-3 w-3 mr-1" />Submitted</Badge>;
      case 'graded':
        return <Badge variant="success"><CheckCircle className="h-3 w-3 mr-1" />Graded</Badge>;
      case 'overdue':
        return <Badge variant="destructive"><AlertCircle className="h-3 w-3 mr-1" />Overdue</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const filteredAssignments = filter === 'all' 
    ? assignments 
    : assignments.filter(assignment => assignment.status === filter);

  return (
    <StudentLayout activeTab="assignments">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {t('assignments')}
          </h1>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap gap-2">
          <Button 
            variant={filter === 'all' ? 'default' : 'outline'}
            onClick={() => setFilter('all')}
          >
            All Assignments
          </Button>
          <Button 
            variant={filter === 'pending' ? 'default' : 'outline'}
            onClick={() => setFilter('pending')}
          >
            Pending
          </Button>
          <Button 
            variant={filter === 'submitted' ? 'default' : 'outline'}
            onClick={() => setFilter('submitted')}
          >
            Submitted
          </Button>
          <Button 
            variant={filter === 'graded' ? 'default' : 'outline'}
            onClick={() => setFilter('graded')}
          >
            Graded
          </Button>
          <Button 
            variant={filter === 'overdue' ? 'default' : 'outline'}
            onClick={() => setFilter('overdue')}
          >
            Overdue
          </Button>
        </div>

        {/* Assignments List */}
        <div className="space-y-4">
          {filteredAssignments.map((assignment) => (
            <Card key={assignment.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      {assignment.title}
                    </CardTitle>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {assignment.subject}
                    </p>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(assignment.status)}
                    {assignment.grade && (
                      <p className="text-lg font-bold text-green-600 mt-2">
                        Grade: {assignment.grade}
                      </p>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {assignment.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Due: {assignment.dueDate}
                    </div>
                    <div className="flex items-center gap-1">
                      <FileText className="h-4 w-4" />
                      Points: {assignment.points}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    {assignment.status === 'pending' && (
                      <Button size="sm">
                        Submit Assignment
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredAssignments.length === 0 && (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">
              No assignments found for the selected filter.
            </p>
          </div>
        )}
      </div>
    </StudentLayout>
  );
};

export default StudentAssignments;

