import React from 'react';
import { useTranslation } from 'react-i18next';
import { Bell, Calendar, User } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import StudentLayout from '@/layouts/StudentLayout';

const StudentAnnouncements = () => {
  const { t } = useTranslation();

  const announcements = [
    {
      id: 1,
      title: '{{AnnouncementTitle1}}',
      content: '{{AnnouncementContent1}}',
      author: '{{TeacherName1}}',
      date: '{{Date1}}',
      type: 'urgent',
      subject: '{{SubjectName1}}'
    },
    {
      id: 2,
      title: '{{AnnouncementTitle2}}',
      content: '{{AnnouncementContent2}}',
      author: '{{TeacherName2}}',
      date: '{{Date2}}',
      type: 'general',
      subject: '{{SubjectName2}}'
    },
    {
      id: 3,
      title: '{{AnnouncementTitle3}}',
      content: '{{AnnouncementContent3}}',
      author: 'Administration',
      date: '{{Date3}}',
      type: 'info',
      subject: 'General'
    }
  ];

  const getTypeBadge = (type) => {
    switch (type) {
      case 'urgent':
        return <Badge variant="destructive">Urgent</Badge>;
      case 'general':
        return <Badge variant="default">General</Badge>;
      case 'info':
        return <Badge variant="secondary">Info</Badge>;
      default:
        return <Badge variant="secondary">General</Badge>;
    }
  };

  return (
    <StudentLayout activeTab="announcements">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('announcements')}</h1>

        <div className="space-y-4">
          {announcements.map((announcement) => (
            <Card key={announcement.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Bell className="h-5 w-5" />
                      {announcement.title}
                    </CardTitle>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {announcement.subject}
                    </p>
                  </div>
                  {getTypeBadge(announcement.type)}
                </div>
              </CardHeader>
              
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {announcement.content}
                </p>
                
                <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    {announcement.author}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {announcement.date}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </StudentLayout>
  );
};

export default StudentAnnouncements;

