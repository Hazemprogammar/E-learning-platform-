import React from 'react';
import { useTranslation } from 'react-i18next';
import { Calendar, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import StudentLayout from '@/layouts/StudentLayout';

const StudentAttendance = () => {
  const { t } = useTranslation();

  const attendanceData = [
    { subject: '{{SubjectName1}}', date: '{{Date1}}', status: 'present', time: '{{Time1}}' },
    { subject: '{{SubjectName2}}', date: '{{Date2}}', status: 'absent', time: '{{Time2}}' },
    { subject: '{{SubjectName3}}', date: '{{Date3}}', status: 'present', time: '{{Time3}}' },
    { subject: '{{SubjectName4}}', date: '{{Date4}}', status: 'late', time: '{{Time4}}' },
    { subject: '{{SubjectName5}}', date: '{{Date5}}', status: 'present', time: '{{Time5}}' },
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'present':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'absent':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'late':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      default:
        return <XCircle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'present': return 'Present';
      case 'absent': return 'Absent';
      case 'late': return 'Late';
      default: return 'Unknown';
    }
  };

  return (
    <StudentLayout activeTab="attendance">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('attendance')}</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-green-600">Present Days</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{{PresentDays}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-red-600">Absent Days</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{{AbsentDays}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-blue-600">Attendance Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{{AttendanceRate}}%</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Attendance History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {attendanceData.map((record, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(record.status)}
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">{record.subject}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{record.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{getStatusText(record.status)}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{record.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
};

export default StudentAttendance;

