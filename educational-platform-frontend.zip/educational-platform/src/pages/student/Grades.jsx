import React from 'react';
import { useTranslation } from 'react-i18next';
import { BarChart3, TrendingUp, Award } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import StudentLayout from '@/layouts/StudentLayout';

const StudentGrades = () => {
  const { t } = useTranslation();

  const subjects = [
    { name: '{{SubjectName1}}', grade: '{{Grade1}}', percentage: '{{Percentage1}}', status: 'excellent' },
    { name: '{{SubjectName2}}', grade: '{{Grade2}}', percentage: '{{Percentage2}}', status: 'good' },
    { name: '{{SubjectName3}}', grade: '{{Grade3}}', percentage: '{{Percentage3}}', status: 'average' },
    { name: '{{SubjectName4}}', grade: '{{Grade4}}', percentage: '{{Percentage4}}', status: 'excellent' },
    { name: '{{SubjectName5}}', grade: '{{Grade5}}', percentage: '{{Percentage5}}', status: 'good' },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-blue-600';
      case 'average': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <StudentLayout activeTab="grades">
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('grades')}</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Overall GPA
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{{OverallGPA}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Class Rank
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{{ClassRank}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Total Credits
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">{{TotalCredits}}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Subject Grades</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {subjects.map((subject, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">{subject.name}</h3>
                  </div>
                  <div className="text-right">
                    <p className={`text-2xl font-bold ${getStatusColor(subject.status)}`}>
                      {subject.grade}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {subject.percentage}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
};

export default StudentGrades;

