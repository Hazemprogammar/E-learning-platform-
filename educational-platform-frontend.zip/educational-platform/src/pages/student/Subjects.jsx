import React from 'react';
import { useTranslation } from 'react-i18next';
import { BookOpen, User, Clock, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import StudentLayout from '@/layouts/StudentLayout';

const StudentSubjects = () => {
  const { t } = useTranslation();

  const subjects = [
    {
      name: '{{SubjectName1}}',
      teacher: '{{TeacherName1}}',
      schedule: '{{Schedule1}}',
      progress: '{{Progress1}}',
      materials: '{{MaterialsCount1}}',
      color: 'bg-blue-500'
    },
    {
      name: '{{SubjectName2}}',
      teacher: '{{TeacherName2}}',
      schedule: '{{Schedule2}}',
      progress: '{{Progress2}}',
      materials: '{{MaterialsCount2}}',
      color: 'bg-green-500'
    },
    {
      name: '{{SubjectName3}}',
      teacher: '{{TeacherName3}}',
      schedule: '{{Schedule3}}',
      progress: '{{Progress3}}',
      materials: '{{MaterialsCount3}}',
      color: 'bg-purple-500'
    },
    {
      name: '{{SubjectName4}}',
      teacher: '{{TeacherName4}}',
      schedule: '{{Schedule4}}',
      progress: '{{Progress4}}',
      materials: '{{MaterialsCount4}}',
      color: 'bg-orange-500'
    },
    {
      name: '{{SubjectName5}}',
      teacher: '{{TeacherName5}}',
      schedule: '{{Schedule5}}',
      progress: '{{Progress5}}',
      materials: '{{MaterialsCount5}}',
      color: 'bg-red-500'
    },
    {
      name: '{{SubjectName6}}',
      teacher: '{{TeacherName6}}',
      schedule: '{{Schedule6}}',
      progress: '{{Progress6}}',
      materials: '{{MaterialsCount6}}',
      color: 'bg-indigo-500'
    }
  ];

  return (
    <StudentLayout activeTab="subjects">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {t('subjects')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {{TotalSubjects}} subjects enrolled
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className={`w-12 h-12 ${subject.color} rounded-lg flex items-center justify-center`}>
                    <BookOpen className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Progress</p>
                    <p className="text-lg font-bold text-blue-600">{subject.progress}%</p>
                  </div>
                </div>
                <CardTitle className="text-xl">{subject.name}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center text-gray-600 dark:text-gray-400">
                  <User className="h-4 w-4 mr-2" />
                  <span className="text-sm">{subject.teacher}</span>
                </div>
                
                <div className="flex items-center text-gray-600 dark:text-gray-400">
                  <Clock className="h-4 w-4 mr-2" />
                  <span className="text-sm">{subject.schedule}</span>
                </div>
                
                <div className="flex items-center text-gray-600 dark:text-gray-400">
                  <FileText className="h-4 w-4 mr-2" />
                  <span className="text-sm">{subject.materials} materials</span>
                </div>

                <div className="pt-4 space-y-2">
                  <Button className="w-full" variant="default">
                    View Materials
                  </Button>
                  <Button className="w-full" variant="outline">
                    View Assignments
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </StudentLayout>
  );
};

export default StudentSubjects;

