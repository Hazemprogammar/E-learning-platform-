import React from 'react';
import { useTranslation } from 'react-i18next';
import { Calendar, BookOpen, FileText, Bell, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import StudentLayout from '@/layouts/StudentLayout';

const StudentDashboard = () => {
  const { t } = useTranslation();

  const upcomingClasses = [
    { subject: '{{SubjectName1}}', time: '{{ClassTime1}}', room: '{{ClassRoom1}}' },
    { subject: '{{SubjectName2}}', time: '{{ClassTime2}}', room: '{{ClassRoom2}}' },
    { subject: '{{SubjectName3}}', time: '{{ClassTime3}}', room: '{{ClassRoom3}}' },
  ];

  const recentGrades = [
    { subject: '{{SubjectName1}}', assignment: '{{AssignmentName1}}', grade: '{{Grade1}}' },
    { subject: '{{SubjectName2}}', assignment: '{{AssignmentName2}}', grade: '{{Grade2}}' },
    { subject: '{{SubjectName3}}', assignment: '{{AssignmentName3}}', grade: '{{Grade3}}' },
  ];

  const pendingAssignments = [
    { subject: '{{SubjectName1}}', title: '{{AssignmentTitle1}}', dueDate: '{{DueDate1}}' },
    { subject: '{{SubjectName2}}', title: '{{AssignmentTitle2}}', dueDate: '{{DueDate2}}' },
    { subject: '{{SubjectName3}}', title: '{{AssignmentTitle3}}', dueDate: '{{DueDate3}}' },
  ];

  return (
    <StudentLayout activeTab="dashboard">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {t('dashboard')}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Welcome back, {{StudentName}}!
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Subjects</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{TotalSubjects}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Assignments</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{PendingAssignments}}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{AttendanceRate}}%</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Grade</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{{AverageGrade}}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Classes */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                {t('upcomingClasses')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingClasses.map((class_, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">{class_.subject}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Room: {class_.room}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-blue-600">{class_.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Grades */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Recent Grades
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentGrades.map((grade, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">{grade.subject}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{grade.assignment}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-600">{grade.grade}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Assignments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Pending Assignments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pendingAssignments.map((assignment, index) => (
                <div key={index} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">{assignment.title}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{assignment.subject}</p>
                  <p className="text-sm text-red-600 font-medium">Due: {assignment.dueDate}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
};

export default StudentDashboard;

