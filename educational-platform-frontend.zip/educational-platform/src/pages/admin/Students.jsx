import React from 'react';
import { useTranslation } from 'react-i18next';
import { Users, Plus, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import AdminLayout from '@/layouts/AdminLayout';

const AdminStudents = () => {
  const { t } = useTranslation();

  const students = [
    { id: '{{StudentID1}}', name: '{{StudentName1}}', email: '{{StudentEmail1}}', grade: '{{Grade1}}', status: 'Active' },
    { id: '{{StudentID2}}', name: '{{StudentName2}}', email: '{{StudentEmail2}}', grade: '{{Grade2}}', status: 'Active' },
    { id: '{{StudentID3}}', name: '{{StudentName3}}', email: '{{StudentEmail3}}', grade: '{{Grade3}}', status: 'Inactive' },
  ];

  return (
    <AdminLayout activeTab="students">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('studentManagement')}</h1>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Student
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              All Students
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">ID</th>
                    <th className="text-left p-2">Name</th>
                    <th className="text-left p-2">Email</th>
                    <th className="text-left p-2">Grade</th>
                    <th className="text-left p-2">Status</th>
                    <th className="text-left p-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student, index) => (
                    <tr key={index} className="border-b">
                      <td className="p-2">{student.id}</td>
                      <td className="p-2 font-medium">{student.name}</td>
                      <td className="p-2">{student.email}</td>
                      <td className="p-2">{student.grade}</td>
                      <td className="p-2">
                        <span className={`px-2 py-1 rounded text-xs ${
                          student.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {student.status}
                        </span>
                      </td>
                      <td className="p-2">
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminStudents;

