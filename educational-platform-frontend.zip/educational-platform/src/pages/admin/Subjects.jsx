import React from 'react';
import { useTranslation } from 'react-i18next';
import { BookOpen, Plus, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import AdminLayout from '@/layouts/AdminLayout';

const AdminSubjects = () => {
  const { t } = useTranslation();

  const subjects = [
    { id: '{{SubjectID1}}', name: '{{SubjectName1}}', teacher: '{{TeacherName1}}', students: '{{StudentCount1}}', status: 'Active' },
    { id: '{{SubjectID2}}', name: '{{SubjectName2}}', teacher: '{{TeacherName2}}', students: '{{StudentCount2}}', status: 'Active' },
    { id: '{{SubjectID3}}', name: '{{SubjectName3}}', teacher: '{{TeacherName3}}', students: '{{StudentCount3}}', status: 'Inactive' },
  ];

  return (
    <AdminLayout activeTab="subjects">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('subjectManagement')}</h1>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Subject
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              All Subjects
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">ID</th>
                    <th className="text-left p-2">Subject Name</th>
                    <th className="text-left p-2">Teacher</th>
                    <th className="text-left p-2">Students</th>
                    <th className="text-left p-2">Status</th>
                    <th className="text-left p-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {subjects.map((subject, index) => (
                    <tr key={index} className="border-b">
                      <td className="p-2">{subject.id}</td>
                      <td className="p-2 font-medium">{subject.name}</td>
                      <td className="p-2">{subject.teacher}</td>
                      <td className="p-2">{subject.students}</td>
                      <td className="p-2">
                        <span className={`px-2 py-1 rounded text-xs ${
                          subject.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {subject.status}
                        </span>
                      </td>
                      <td className="p-2">
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminSubjects;

