import React from 'react';
import { useTranslation } from 'react-i18next';
import { Calendar, Plus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import AdminLayout from '@/layouts/AdminLayout';

const AdminSchedule = () => {
  const { t } = useTranslation();

  const schedule = [
    { time: '08:00-09:00', monday: '{{Subject1}}', tuesday: '{{Subject2}}', wednesday: '{{Subject3}}', thursday: '{{Subject4}}', friday: '{{Subject5}}' },
    { time: '09:00-10:00', monday: '{{Subject2}}', tuesday: '{{Subject3}}', wednesday: '{{Subject4}}', thursday: '{{Subject5}}', friday: '{{Subject1}}' },
    { time: '10:00-11:00', monday: '{{Subject3}}', tuesday: '{{Subject4}}', wednesday: '{{Subject5}}', thursday: '{{Subject1}}', friday: '{{Subject2}}' },
  ];

  return (
    <AdminLayout activeTab="schedule">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('scheduleBuilder')}</h1>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Schedule
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Weekly Schedule
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="border p-2 bg-gray-50 dark:bg-gray-800">Time</th>
                    <th className="border p-2 bg-gray-50 dark:bg-gray-800">Monday</th>
                    <th className="border p-2 bg-gray-50 dark:bg-gray-800">Tuesday</th>
                    <th className="border p-2 bg-gray-50 dark:bg-gray-800">Wednesday</th>
                    <th className="border p-2 bg-gray-50 dark:bg-gray-800">Thursday</th>
                    <th className="border p-2 bg-gray-50 dark:bg-gray-800">Friday</th>
                  </tr>
                </thead>
                <tbody>
                  {schedule.map((slot, index) => (
                    <tr key={index}>
                      <td className="border p-2 font-medium">{slot.time}</td>
                      <td className="border p-2">{slot.monday}</td>
                      <td className="border p-2">{slot.tuesday}</td>
                      <td className="border p-2">{slot.wednesday}</td>
                      <td className="border p-2">{slot.thursday}</td>
                      <td className="border p-2">{slot.friday}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminSchedule;

