import React from 'react';
import { useTranslation } from 'react-i18next';
import { Moon, Sun, Globe, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/utils/ThemeContext';
import { useState } from 'react';

const Header = ({ userRole = null, onLogout = null }) => {
  const { t, i18n } = useTranslation();
  const { theme, toggleTheme } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleLanguage = () => {
    const newLang = i18n.language === 'ar' ? 'en' : 'ar';
    i18n.changeLanguage(newLang);
    document.dir = newLang === 'ar' ? 'rtl' : 'ltr';
  };

  const isRTL = i18n.language === 'ar';

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm border-b border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                {isRTL ? 'منصة التعليم الرقمية' : 'Digital Education Platform'}
              </h1>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4 rtl:space-x-reverse">
            {!userRole && (
              <>
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">
                  {t('home')}
                </Button>
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">
                  {t('about')}
                </Button>
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">
                  {t('contact')}
                </Button>
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">
                  {t('faq')}
                </Button>
              </>
            )}
            
            {userRole && (
              <>
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">
                  {t('dashboard')}
                </Button>
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">
                  {t('profile')}
                </Button>
                {onLogout && (
                  <Button variant="ghost" onClick={onLogout} className="text-gray-700 dark:text-gray-300">
                    {t('logout')}
                  </Button>
                )}
              </>
            )}
          </nav>

          {/* Controls */}
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            {/* Language Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="p-2"
              title={t('language')}
            >
              <Globe className="h-4 w-4" />
              <span className="ml-1 text-xs">{i18n.language.toUpperCase()}</span>
            </Button>

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="p-2"
              title={theme === 'light' ? t('darkMode') : t('lightMode')}
            >
              {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col space-y-2">
              {!userRole && (
                <>
                  <Button variant="ghost" className="justify-start text-gray-700 dark:text-gray-300">
                    {t('home')}
                  </Button>
                  <Button variant="ghost" className="justify-start text-gray-700 dark:text-gray-300">
                    {t('about')}
                  </Button>
                  <Button variant="ghost" className="justify-start text-gray-700 dark:text-gray-300">
                    {t('contact')}
                  </Button>
                  <Button variant="ghost" className="justify-start text-gray-700 dark:text-gray-300">
                    {t('faq')}
                  </Button>
                </>
              )}
              
              {userRole && (
                <>
                  <Button variant="ghost" className="justify-start text-gray-700 dark:text-gray-300">
                    {t('dashboard')}
                  </Button>
                  <Button variant="ghost" className="justify-start text-gray-700 dark:text-gray-300">
                    {t('profile')}
                  </Button>
                  {onLogout && (
                    <Button variant="ghost" onClick={onLogout} className="justify-start text-gray-700 dark:text-gray-300">
                      {t('logout')}
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;

