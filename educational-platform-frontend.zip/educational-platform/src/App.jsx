import React, { useState, useEffect } from 'react';
import apiService from './services/api';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      if (apiService.token) {
        const response = await apiService.getProfile();
        if (response.success) {
          setUser(response.data);
        }
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      apiService.setToken(null);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await apiService.login(loginForm.email, loginForm.password);
      if (response.success) {
        setUser(response.data.user);
        setLoginForm({ email: '', password: '' });
      }
    } catch (error) {
      setError(error.message || 'فشل في تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await apiService.logout();
      setUser(null);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleInputChange = (e) => {
    setLoginForm({
      ...loginForm,
      [e.target.name]: e.target.value
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full space-y-8">
          <div>
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              منصة التعليم الرقمية
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              تسجيل الدخول إلى حسابك
            </p>
          </div>
          <form className="mt-8 space-y-6" onSubmit={handleLogin}>
            <div className="rounded-md shadow-sm -space-y-px">
              <div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  placeholder="البريد الإلكتروني"
                  value={loginForm.email}
                  onChange={handleInputChange}
                />
              </div>
              <div>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  placeholder="كلمة المرور"
                  value={loginForm.password}
                  onChange={handleInputChange}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={loading}
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
              </button>
            </div>

            <div className="text-center text-sm text-gray-600">
              <p>حسابات تجريبية:</p>
              <p>مدير: admin@school.com</p>
              <p>معلم: teacher1@school.com</p>
              <p>طالب: student1@school.com</p>
              <p>كلمة المرور: password</p>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900">
                منصة التعليم الرقمية
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-700">مرحباً، {user.name}</span>
              <span className="px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                {user.role === 'student' ? 'طالب' : user.role === 'teacher' ? 'معلم' : 'مدير'}
              </span>
              <button
                onClick={handleLogout}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                تسجيل الخروج
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              مرحباً بك في منصة التعليم الرقمية
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              تم تسجيل الدخول بنجاح كـ {user.role === 'student' ? 'طالب' : user.role === 'teacher' ? 'معلم' : 'مدير'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              {user.role === 'student' && (
                <>
                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📚</span>
                    </div>
                    <h3 className="text-xl font-bold text-blue-600 mb-4">المواد الدراسية</h3>
                    <p className="text-gray-600">
                      عرض جميع المواد المسجل بها
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📝</span>
                    </div>
                    <h3 className="text-xl font-bold text-green-600 mb-4">الواجبات</h3>
                    <p className="text-gray-600">
                      عرض الواجبات والمهام المطلوبة
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📊</span>
                    </div>
                    <h3 className="text-xl font-bold text-purple-600 mb-4">الدرجات</h3>
                    <p className="text-gray-600">
                      متابعة الدرجات والأداء الأكاديمي
                    </p>
                  </div>
                </>
              )}

              {user.role === 'teacher' && (
                <>
                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">👥</span>
                    </div>
                    <h3 className="text-xl font-bold text-blue-600 mb-4">الفصول</h3>
                    <p className="text-gray-600">
                      إدارة الفصول والطلاب
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📋</span>
                    </div>
                    <h3 className="text-xl font-bold text-green-600 mb-4">الحضور</h3>
                    <p className="text-gray-600">
                      تسجيل حضور الطلاب
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📢</span>
                    </div>
                    <h3 className="text-xl font-bold text-purple-600 mb-4">الإعلانات</h3>
                    <p className="text-gray-600">
                      نشر الإعلانات للطلاب
                    </p>
                  </div>
                </>
              )}

              {user.role === 'admin' && (
                <>
                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">👤</span>
                    </div>
                    <h3 className="text-xl font-bold text-blue-600 mb-4">إدارة المستخدمين</h3>
                    <p className="text-gray-600">
                      إدارة الطلاب والمعلمين
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📚</span>
                    </div>
                    <h3 className="text-xl font-bold text-green-600 mb-4">إدارة المواد</h3>
                    <p className="text-gray-600">
                      إضافة وتعديل المواد الدراسية
                    </p>
                  </div>

                  <div className="bg-white p-8 rounded-lg shadow-lg">
                    <div className="w-16 h-16 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <span className="text-white text-2xl font-bold">📊</span>
                    </div>
                    <h3 className="text-xl font-bold text-purple-600 mb-4">الإحصائيات</h3>
                    <p className="text-gray-600">
                      عرض إحصائيات النظام
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;

